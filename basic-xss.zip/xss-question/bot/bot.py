import hmac
import os
import threading
import time

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from flask import Flask, jsonify, request

BASE_URL = os.environ.get("WEB_URL", "http://web:5000")
BOT_SECRET = os.environ["BOT_SECRET"]
FLAG = os.environ.get("FLAG", "flag{set_FLAG_env_var}")
CHROME_BIN = os.environ.get("CHROME_BIN", "/usr/bin/chromium")
CHROMEDRIVER_BIN = os.environ.get("CHROMEDRIVER_BIN", "/usr/bin/chromedriver")
BOT_PORT = int(os.environ.get("BOT_PORT", "6000"))

RENDER_WAIT_SECONDS = 3

app = Flask(__name__)


def new_driver():
    options = Options()
    options.binary_location = CHROME_BIN
    options.add_argument("--headless=new")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    return webdriver.Chrome(service=Service(CHROMEDRIVER_BIN), options=options)


def visit(report_id):
    """Load the report as if an admin were viewing it, flag cookie in hand."""
    driver = new_driver()
    try:
        driver.get(f"{BASE_URL}/login")
        driver.add_cookie({"name": "flag", "value": FLAG, "path": "/"})
        driver.get(f"{BASE_URL}/report/{report_id}/view")
        time.sleep(RENDER_WAIT_SECONDS)
    finally:
        driver.quit()


def review(report_id):
    try:
        visit(report_id)
    except Exception as e:
        print(f"[bot] error visiting report {report_id}: {e}")


@app.route("/visit", methods=["POST"])
def handle_visit():
    if not hmac.compare_digest(request.headers.get("X-Bot-Secret", ""), BOT_SECRET):
        return "forbidden", 403
    report_id = (request.get_json(silent=True) or {}).get("report_id")
    if not report_id:
        return "bad request", 400
    threading.Thread(target=review, args=(report_id,), daemon=True).start()
    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=BOT_PORT)
